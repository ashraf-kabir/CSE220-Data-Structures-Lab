package wrm;

public class QueueUnderflowException extends Exception {
	
}
