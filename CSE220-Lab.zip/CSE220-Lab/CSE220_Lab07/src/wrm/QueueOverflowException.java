package wrm;

public class QueueOverflowException extends Exception {
	
}
