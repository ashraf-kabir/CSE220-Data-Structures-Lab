package wrm;

public class Patient {
	
	public Object id;
	// public Object
	public String name;
	public int age;

	public Patient(String n, int a, int i) {
		name = n;
		age = a;
		id = i;
	}
}
