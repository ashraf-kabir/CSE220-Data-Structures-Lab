package task02;

public class Task02 {

	public static void main(String[] args) {

		int a = 1 / 0;
		//System.out.println(a);
	}

}
