package task01;

public class StackUnderflowException extends Exception{

}
