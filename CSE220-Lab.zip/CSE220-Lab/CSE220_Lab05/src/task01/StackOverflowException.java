package task01;

public class StackOverflowException extends Exception{

}
