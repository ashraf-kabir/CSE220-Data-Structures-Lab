package task02;

public class QueueUnderflowException extends Exception {

}