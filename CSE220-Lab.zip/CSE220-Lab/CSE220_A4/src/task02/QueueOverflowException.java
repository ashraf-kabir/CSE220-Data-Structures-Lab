package task02;

public class QueueOverflowException extends Exception {

}