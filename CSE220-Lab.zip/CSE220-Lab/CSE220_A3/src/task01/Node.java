package task01;

public class Node {

	Object key;
	Node next;

	public Node(Object k, Node n) {
		key = k;
		next = n;
	}

}
